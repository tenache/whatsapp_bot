#!/usr/bin/env python
from langchain.callbacks.manager import CallbackManager
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate, ChatPromptTemplate, FewShotChatMessagePromptTemplate
from langchain_community.llms import LlamaCpp
from langchain_core.output_parsers import StrOutputParser
from fastapi import FastAPI
from langserve import add_routes

app = FastAPI(
    title="LangChain Server",
    version="1.0",
    description="A simple api server using Langchain's Runnable interfaces",
)

model = LlamaCpp(
    model_path=r"C:\Users\BlackFish01\Desktop\llamapython\Release\llama-2-7b.Q5_K_M.gguf",
    temperature=0.75,
    max_tokens=2000,
    top_p=1,
    #callback_manager=callback_manager,
    verbose=True,  # Verbose is required to pass to the callback manager
)
# prompt = ChatPromptTemplate.from_messages([
#             ("system", """Eres un amable asistente de la compañia O.FRE.SER
#              y debes responder consultas en base al siguiente mensaje que recibio 
#              el cliente:
#              'O.FRE.SER - Gestión Integral de Plagas 

# Señor cliente, le informamos que su servicio en domicilio SAN MARTIN 1233
# está programado para el día de mañana a horas 16:45.
# Para confirmar su turno deberá comunicarse con nuestro personal de atención al
# público.


# De lunes a viernes de 9hs a 20hs, sábado de 9hs a 13hs.

# Tel: 4212368
# Cel: 387528693

# Puede abonar por transferencia o por tarjeta de credito llamando a alguno de
# los numeros proporcionados.

# Por consultas o sugerencias, comunicarse vía whatsapp
# ====> https://wa.me/5493875286093

# IMPORTANTE
# Por favor agende éste número para poder seguir recibiendo este tipo de
# notificaciones.
# Segumos trabajando para mejorar nuestros servicios.

# Muchas gracias
# Área Administración y Logística' """),
#             ("human", "Hola, ¿Como puedo abonar?"),
#             ("ai", "¡Hola!, puede abonar comunicandose con los numeros proporcionados."),
#             ("human", "{user_input}"),
#         ])
prompt = ChatPromptTemplate.from_messages([
            ("system", """Eres un apasionado biologo de focas y respondes a las preguntas
                sobre las focas en menos de 70 palabras con felicidad y siempre terminas las oraciones con 'FISBH!'"""),
            # ("human", "Hola, ¿Como puedo abonar?"),
            # ("ai", "¡Hola!, puede abonar comunicandose con los numeros proporcionados."),
            # ("human", "{user_input}"),
        ])
#prompt = ChatPromptTemplate.from_template("tell me a joke about {topic}")
add_routes(
    app,
    prompt | model,
    path="/joke",
)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="localhost", port=10200)